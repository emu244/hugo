---
title: "Bourses d’études"
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# image
image: "images/about/about-page.jpg"
# meta description
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. dolore magna aliqua. Ut enim ad minim veniam, quis nostrud."
---

## NOUVELLES SUR LES BOURSES D’ÉTUDE

**_NOS CAMPUS SONT DES LABORATOIRES VIVANTS DURABLES._**

Lorem ipsum dolor sit amet, consectetur adipi sicing elit, sed do eiusmod tempor incididunt ut labore
et.dolore magna aliquauis aute irure dolor.
in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor, sit
amet consectetur adipisicing elit. Quas cum ut ab nesciunt distinctio maxime expedita fugit laborum? Aliquid,
quia.
