---
title: "Conférence sur les médias sociaux et l’économie béhaviorale"
date: 2019-07-06T15:27:17+06:00
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# meta description
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. dolore magna aliqua. Ut enim ad minim veniam, quis nostrud."
# Event image
image: "images/events/event-2.jpg"
# location
location: "Dhanmondi, Dhaka"
# entry fee
fee: "À partir de 699$"
# apply url
apply_url : "#"
# event speaker
speaker:
  # speaker loop
  - name : "Jack Mastio"
    image : "images/event-speakers/speaker-1.jpg"
    designation : "Enseignant"

  # speaker loop
  - name : "John Doe"
    image : "images/event-speakers/speaker-2.jpg"
    designation : "Enseignant"

  # speaker loop
  - name : "Randy Luis"
    image : "images/event-speakers/speaker-3.jpg"
    designation : "Enseignant"

  # speaker loop
  - name : "Alfred Jin"
    image : "images/event-speakers/speaker-4.jpg"
    designation : "Enseignant"

# type
type: "event"
---

### À propos de l’événement

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat  pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.